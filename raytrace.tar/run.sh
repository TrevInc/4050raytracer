#!/bin/bash

time ./raytrace tetrahedron.obj
display "images/out.png"
