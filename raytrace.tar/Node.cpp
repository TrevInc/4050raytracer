#include "Node.h"

Node::Node(const void *data) : 
	data(data), 
	next(NULL) {}

