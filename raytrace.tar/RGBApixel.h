#ifndef RGBAPIXEL
#define RGBAPIXEL

struct RGBApixel {
   unsigned char red, green, blue, alpha;
};

#endif
