#ifndef ENUMCOLORS_H
#define ENUMCOLORS_H

enum Colors {
	RED, 
	GREEN, 
	BLUE, 
	ORANGE, 
	PURPLE, 
	DARK_PURPLE, 
	WHITE, 
	BLACK, 
	CYAN, 
	MAGENTA, 
	YELLOW
};

#endif
